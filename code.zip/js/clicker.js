'use strict';
var clicker = angular.module('clicker', [

    'clickerGame'
]);
//Déclaration du module
var clickerGame = angular.module('clickerGame',[]);

//Déclaration du controleur
clickerGame.controller('clickerCtrl', ['$scope', function($scope) {
		$scope.clicks=0; // nombre initial
		$scope.click = function () {
			//ajout d'un click
            $scope.clicks++;
        }
	}]);